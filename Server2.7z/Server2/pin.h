#ifndef PIN_H
#define PIN_H


class Pin
{
    public:
            Pin(int var);
           void get(int nr_p);
           void set(int nr_p);
           void change_dir(int nr_p);
           int p;
           int dir;
           char pull_up;


};
#endif // PIN_H
